#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Actual rclpy raw-subscription/rosbag2 recipe. NOT executed in the sandbox.

Run only using the isolated container recipe. All publishers are simulated
observation publishers, never robot commands. No services/actions are invoked.
"""
import argparse
from functools import partial
import json
import os
from pathlib import Path
import time
import xml.etree.ElementTree as ET

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from rclpy.event_handler import SubscriptionEventCallbacks
from rclpy.serialization import deserialize_message
from ament_index_python.packages import get_package_share_directory
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String
from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus
import rosbag2_py
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from bundle import Capture, NS, TOPICS, encoded, export_capture, public_bytes

TYPES = {"/demo/movement": PoseStamped, "/demo/control_mode": String,
         "/demo/diagnostics": DiagnosticArray}
QOS = QoSProfile(history=HistoryPolicy.KEEP_LAST, depth=8,
                 reliability=ReliabilityPolicy.BEST_EFFORT,
                 durability=DurabilityPolicy.VOLATILE)
EXPECTED = {"rclpy": "7.1.12", "rmw_fastrtps_cpp": "8.4.4", "rosbag2_py": "0.26.11"}


def environment():
    actual = {name: ET.parse(Path(get_package_share_directory(name)) / "package.xml").findtext("version")
              for name in EXPECTED}
    if actual != EXPECTED:
        raise RuntimeError(f"version mismatch; no silent fallback: {actual} != {EXPECTED}")
    if os.environ.get("RMW_IMPLEMENTATION") != "rmw_fastrtps_cpp":
        raise RuntimeError("explicit rmw_fastrtps_cpp required")
    if os.environ.get("PASK_ISOLATED_DEMO") != "container-network-none":
        raise RuntimeError("use the documented network-none container; domain id is not isolation")
    # Environment flag is an accidental-misuse guard, NOT proof of isolation.
    return actual | {"ROS_DISTRO": os.environ.get("ROS_DISTRO"),
                     "input": "ROS2-CDR", "ros_runtime": "executed-by-this-process",
                     "isolation_assertion": "operator container-network-none"}


class Publisher(Node):
    def __init__(self):
        super().__init__("pask_fixture_publisher", enable_rosout=False, start_parameter_services=False)
        self.outputs = {topic: self.create_publisher(cls, topic, QOS) for topic, cls in TYPES.items()}
        self.tick = 0
        self.done = False
        self.timer = self.create_timer(0.1, self.emit)

    def emit(self):
        tick = self.tick
        stamp = tick * NS // 10 - (2 * NS if tick >= 80 else 0)
        msg = PoseStamped()
        msg.header.stamp.sec, msg.header.stamp.nanosec = divmod(stamp, NS)
        msg.header.frame_id = "map"
        msg.pose.position.x = tick * 0.01
        msg.pose.orientation.w = 1.0
        self.outputs["/demo/movement"].publish(msg)
        if tick % 5 == 0:
            if not 70 <= tick <= 85:
                mode = String()
                mode.data = "assisted" if tick >= 60 else "autonomous"
                self.outputs["/demo/control_mode"].publish(mode)
            diag = DiagnosticArray()
            diag.header.stamp.sec, diag.header.stamp.nanosec = divmod(tick * NS // 10, NS)
            status = DiagnosticStatus()
            status.level = 2 if tick == 60 else 0
            status.name = "simulated-inspection"
            status.message = "test trigger" if tick == 60 else "nominal"
            status.hardware_id = "SIMULATED-NOT-TEE"
            diag.status = [status]
            self.outputs["/demo/diagnostics"].publish(diag)
        self.tick += 1
        if self.tick > 120:
            self.done = True
            self.timer.cancel()


class Collector(Node):
    def __init__(self):
        super().__init__("pask_fixture_collector", enable_rosout=False, start_parameter_services=False)
        self.capture = Capture()
        self.started = time.monotonic_ns()
        self.local_sequences = {t: 0 for t in TYPES}
        self.subscriptions_ = [
            self.create_subscription(
                cls, topic, partial(self.receive, topic, cls), QOS, raw=True,
                event_callbacks=SubscriptionEventCallbacks(
                    incompatible_qos=partial(self.qos_error, topic)))
            for topic, cls in TYPES.items()]
        self.create_timer(0.02, self.capture.drain)

    def qos_error(self, topic, event):
        self.capture.issue("qos_incompatible", topic, time.monotonic_ns() - self.started,
                           total_count=event.total_count)

    def receive(self, topic, cls, data):
        now = time.monotonic_ns() - self.started
        if len(data) > self.capture.limits["record_bytes"]:
            self.capture.issue("oversize_record", topic, now)
            return
        try:
            msg = deserialize_message(data, cls)
            stamp = getattr(getattr(msg, "header", None), "stamp", None)
            source = None if stamp is None else stamp.sec * NS + stamp.nanosec
            self.local_sequences[topic] += 1
            r = {"topic": topic, "raw": bytes(data), "type": TOPICS[topic]["type"],
                 "wire_encoding": "ROS2-CDR", "source_ns": source,
                 "source_sequence": None, "sequence_origin": "not-supplied-by-selected-ROS-types",
                 "collector_sequence": self.local_sequences[topic],
                 "source_clock": None if stamp is None else "fixture-stamped-simulated/source",
                 "receive_ns": now, "receive_clock": "collector-monotonic-relative",
                 "frame": getattr(getattr(msg, "header", None), "frame_id", None),
                 "units": "m" if topic == "/demo/movement" else None,
                 "interpretation": "simulated",
                 "trigger": topic == "/demo/diagnostics" and any(s.level >= 2 for s in msg.status)}
            self.capture.submit(r)
        except (ValueError, TypeError, RuntimeError) as exc:
            self.capture.issue("decode_or_ingress_error", topic, now, detail=str(exc)[:256])

    def export(self, output, versions):
        self.capture.drain()
        # Writer is reused for storage, not a newly implemented bag format.
        bag = Path("/tmp/event-bag")
        writer = rosbag2_py.SequentialWriter()
        writer.open(rosbag2_py.StorageOptions(uri=str(bag), storage_id="sqlite3",
                                             max_cache_size=0),
                    rosbag2_py.ConverterOptions("", ""))
        for topic in TYPES:
            writer.create_topic(rosbag2_py.TopicMetadata(
                id=0, name=topic, type=TOPICS[topic]["type"], serialization_format="cdr"))
        for r in self.capture.event:
            writer.write(r["topic"], r["raw"], r["receive_ns"])
        del writer  # close and finalize metadata before hashing files
        extras = {}
        for path in bag.iterdir():
            if path.is_file():
                extras["rosbag2/" + path.name] = path.read_bytes()
        # Preserve actual installed schema definitions, including nested dependencies.
        for package in ("geometry_msgs", "std_msgs", "diagnostic_msgs", "builtin_interfaces"):
            share = Path(get_package_share_directory(package))
            extras[f"ros-schema/{package}/package.xml"] = (share / "package.xml").read_bytes()
            for path in sorted((share / "msg").iterdir()):
                if path.suffix in (".msg", ".idl"):
                    extras[f"ros-schema/{package}/{path.name}"] = path.read_bytes()
        topics = self.get_topic_names_and_types()
        services = self.get_service_names_and_types()
        if set(name for name, _ in topics) - set(TYPES) - {"/parameter_events"} or services:
            raise RuntimeError("unexpected graph endpoints: fail closed")
        graph = {"topics": [[name, types] for name, types in topics],
                 "services": [[name, types] for name, types in services],
                 "expected_observation_topics": sorted(TYPES),
                 "permitted_auxiliary_topics": ["/parameter_events"],
                 "parameter_services_enabled": False, "rosout_enabled": False,
                 "actions_created": [], "recorder_control_services_created": [],
                 "note": "parameter event topic permitted by local graph policy; no parameter RPCs"}
        extras["ros-graph.json"] = encoded(graph)
        extras["ros-capture-metadata.json"] = encoded({
            "actual_schema_objects": "ros-schema/",
            "native_period_ns": {t: spec["period_ns"] for t, spec in TOPICS.items()},
            "qos": "best-effort/volatile/keep-last-8",
            "qos_status": "incompatible callbacks reported; delivery completeness not proven",
            "original_bytes": "raw rclpy CDR callback; rosbag2 stores same payload",
            "bag_timestamp": "collector monotonic relative nanoseconds, not ROS wall time",
            "replay": "only network-none graph; play publishes messages"})
        key = Ed25519PrivateKey.generate()
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        (Path(output).parent / "enrollment-public-key.hex").write_text(
            public_bytes(key).hex() + "\n")
        self.capture.issue("timing_relationship_unestablished", detail="source stamps not wall time")
        result = export_capture(self.capture, output, key, versions, extras)
        print(json.dumps(result, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("role", choices=["publish", "collect"])
    parser.add_argument("--output", default="/out/final-bundle")
    args = parser.parse_args()
    versions = environment()
    rclpy.init()
    node = Publisher() if args.role == "publish" else Collector()
    deadline = time.monotonic() + (15 if args.role == "publish" else 17)
    try:
        while time.monotonic() < deadline and not getattr(node, "done", False):
            rclpy.spin_once(node, timeout_sec=0.05)
        if args.role == "collect":
            node.export(args.output, versions)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
